# Flexbox Holy Grail 

A Pen created on CodePen.io. Original URL: [https://codepen.io/azwebproductions/pen/eYrYYma](https://codepen.io/azwebproductions/pen/eYrYYma).

Example from: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Flexible_Box_Layout/Using_CSS_flexible_boxes